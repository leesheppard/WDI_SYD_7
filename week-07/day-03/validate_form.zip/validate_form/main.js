$(function() {
  // listen for the submit event on the form
  // if there isn't at least 1 character in a field
  // show an error in the span next to that field in the HTML
});